# Fairway · GitHub Pages

## Cómo subir (importante)

1. Crea un repo (ej. `fairway`).
2. Sube **todo** el contenido de esta carpeta a la **raíz** del repo (o a `/docs`):
   - `index.html`  ← tiene que llamarse exactamente así
   - `manifest.webmanifest`
   - `sw.js`
   - `icons/` (carpeta completa)
3. Settings → Pages → Deploy from branch → `main` / root (o `/docs`).
4. Espera 1–2 min y abre:
   `https://TU_USUARIO.github.io/fairway/`

## Errores típicos

- Solo subiste el HTML con otro nombre (`Fairway-personal-v1.html`) → 404. Renómbralo a `index.html`.
- Faltan `icons/`, `manifest` o `sw.js` → la app puede cargar pero el icono PWA no.
- Repo en carpeta anidada (`repo/deploy/index.html`) sin configurar Pages a esa carpeta → 404.

## iPhone

Safari → la URL HTTPS → Compartir → Añadir a pantalla de inicio.
